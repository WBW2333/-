//获取分词函数
async function participle(){
    var text = document.getElementById("textArea").value;
    let target = await eel.jiebafenci(text)()
    document.getElementById("hideParticiple").disabled = false;
    var res = document.getElementById("form");
    res.innerHTML = null;
    var legend = document.createElement("legend");
    legend.innerHTML = "分词结果：";
    res.appendChild(legend);
    var button = document.getElementById("hideParticiple")
    if (button.innerHTML === "显示分词结果") {
        res.hidden = false;
        button.innerHTML = "隐藏分词结果";
    }
    var title = document.createElement('p');
    title.innerHTML = "名词：";
    res.appendChild(title);
    res.appendChild(await creatItem(target[0], "noun"));
    title = document.createElement('p');
    title.innerHTML = "形容词：";
    res.appendChild(title);
    res.appendChild(await creatItem(target[1], "adj"));
    title = document.createElement('p');
    title.innerHTML = "动词：";
    res.appendChild(title);
    res.appendChild(await creatItem(target[2], "verb"));
    title = document.createElement('p');
    title.innerHTML = "其他：";
    res.appendChild(title);
    res.appendChild(await creatItem(target[3], "other"));
}

/**
 * 创建网页元素
 */
async function creatItem(words, category) {
    var word;
    var res = document.createElement("from");
    var flag = 0;
    for (word in words){
        var div = document.createElement("div");
        div.setAttribute("class", "item")
        var response = document.createElement('input');
        response.setAttribute("type", "checkbox");
        response.setAttribute("name", category);
        response.setAttribute("value", words[word]);
        response.setAttribute("id", category + word);
        response.setAttribute("onclick", "wordSelect("+category + word+")");
        div.appendChild(response);
        var x = document.createElement("label");
        var t = document.createTextNode(words[word]);
        x.setAttribute("for", category + word);
        x.appendChild(t);
        div.appendChild(x);
        res.appendChild(div)
    }
    return res;
}