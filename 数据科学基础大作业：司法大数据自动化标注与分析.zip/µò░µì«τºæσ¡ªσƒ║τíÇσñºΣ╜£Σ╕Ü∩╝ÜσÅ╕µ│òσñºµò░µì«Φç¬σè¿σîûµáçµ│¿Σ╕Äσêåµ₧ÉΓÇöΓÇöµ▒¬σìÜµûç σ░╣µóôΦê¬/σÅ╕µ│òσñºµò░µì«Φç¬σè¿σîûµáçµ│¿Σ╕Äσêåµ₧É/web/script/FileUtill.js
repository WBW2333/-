/**
 * 从txt文件中读取案件信息
 * @param event
 */
var openFile = function (event) {
            var input = event.target;
            var reader = new FileReader();
            reader.onload = function () {
                if (reader.result) {
                    // console.log(reader.result);
                    document.getElementById("textArea").value = reader.result;
                }
            };
            reader.readAsText(input.files[0]);
        };


// document.write('<script src="FileSaver.js" type="text/javascript" charset="utf-8"></script>');
var timeStamp;
var isSuccess = true;

/**
 * 保存案件文本和标注信息
 */
function saveFile(){
    timeStamp = new Date().getTime();
    saveTxt();
    saveJSON();
    if (isSuccess) {
        window.alert("已成功保存案件文本和标注信息到download路径下。")
    }
}
/**
 * 保存案件文本.txt
 */
async function saveTxt(){
    var textArea = document.getElementById('textArea');
    var textAreaContent = textArea.value;
    if (textAreaContent) {
        // var file = new File([textAreaContent], "案件文本"+timeStamp+".txt", { type: "text/plain;charset=utf-8"  });
        // saveAs(file);
        await eel.create_file(textAreaContent, "案件文本"+timeStamp+".txt")
    } else {
        window.alert("你尚未输入案件文本，请重新输入");
        isSuccess = false;
    }
}

/**
 * 保存标注.json
 */
async function saveJSON(){
    var textList = document.querySelectorAll(".text");

    var unMarked = "";
    for (var i = 0; i < textList.length; i++) {
        if (!textList[i].value) {
            unMarked += (textList[i].placeholder + "，");
        }
    }

    if (unMarked) {
        window.alert("你尚未标注：" + unMarked + "请标注");
        isSuccess = false;
    } else {
        var textContents = [];
        for (var i = 0; i < textList.length; i++) {
            var JSON = '"' + textList[i].placeholder + '":' + '"' + textList[i].value + '"';
            textContents.push(JSON);
        }
        var JSONList = "{" + textContents.join(",") + "}";
        // var blob = new Blob([JSONList], {type: "text/plain;charset=utf-8"});
        // saveAs(blob, "标注"+timeStamp+".json");
        await eel.create_file(JSONList, "标注"+timeStamp+".json")
    }
}