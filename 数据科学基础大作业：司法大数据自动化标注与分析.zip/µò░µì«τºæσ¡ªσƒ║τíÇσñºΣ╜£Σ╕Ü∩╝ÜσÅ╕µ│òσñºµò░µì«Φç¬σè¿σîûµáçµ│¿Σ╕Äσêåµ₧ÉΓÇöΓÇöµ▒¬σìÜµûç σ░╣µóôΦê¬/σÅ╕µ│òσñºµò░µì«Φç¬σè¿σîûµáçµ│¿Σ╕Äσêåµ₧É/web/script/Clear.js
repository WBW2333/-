/**
 * 清空案件文本
 */
function clearContent(){
    var textArea = document.getElementById('textArea');
    textArea.value = "";
    document.getElementById("fileUploader").value = null;
    document.getElementById("participle").value = null;
    document.getElementById("hideParticiple").disabled = true;
    document.getElementById("form").innerHTML = null;
    document.getElementById("form").children = null;
    document.getElementById("partyRadio").checked = true;
    tagID = "party";
    var a = $("input[type='radio']");
    a.parent().css('background','#F5A623');
    a.next().css('color','white');
    a.first().parent().css('background','#ea641b');
    a.first().next().css('color','black');
    var button = document.getElementById("hideParticiple")
    var form = document.getElementById('form')
    form.hidden = true;
    button.innerHTML = "显示分词结果";
    clearMark();
}

/**
 * 隐藏/显示分词结果
 */
function hideParticiple(){
    var button = document.getElementById("hideParticiple")
    var form = document.getElementById('form')
    if (button.innerHTML === "隐藏分词结果") {
        form.hidden = true;
        button.innerHTML = "显示分词结果";
    } else {
        form.hidden = false;
        button.innerHTML = "隐藏分词结果";
    }
}

/**
 * 清空标注
 */
function clearMark(){
    var textList = document.querySelectorAll(".text");
    for(var i = 0; i < textList.length; i++){
        textList[i].value = "";
    }
    wordsOfParty.clear();
    wordsOfSex.clear();
    wordsOfNationality.clear();
    wordsOfBirthPlace.clear();
    wordsOfCause.clear();
    wordsOfCourt.clear();
}