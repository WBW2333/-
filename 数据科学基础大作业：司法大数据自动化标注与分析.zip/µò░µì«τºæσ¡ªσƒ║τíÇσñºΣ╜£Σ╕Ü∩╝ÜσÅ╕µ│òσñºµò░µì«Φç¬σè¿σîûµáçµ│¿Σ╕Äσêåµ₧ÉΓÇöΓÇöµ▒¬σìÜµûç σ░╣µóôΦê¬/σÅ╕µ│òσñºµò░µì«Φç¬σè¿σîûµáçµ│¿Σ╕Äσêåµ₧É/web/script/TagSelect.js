var tagID = "party";
var wordsOfParty = new Set();
var wordsOfSex = new Set();
var wordsOfNationality = new Set();
var wordsOfBirthPlace = new Set();
var wordsOfCause = new Set();
var wordsOfCourt = new Set();

$(document).ready(function() {
    $('input[type=radio][name=tags]').change(function() {
        tagID = this.value;
        var words;
        switch (tagID) {
            case "party": words = wordsOfParty; break;
            case "sex": words = wordsOfSex; break;
            case "nationality": words = wordsOfNationality; break;
            case "birthPlace": words = wordsOfBirthPlace; break;
            case "cause": words = wordsOfCause; break;
            case "court": words = wordsOfCourt; break;
        }
        var checkBox = document.getElementsByName("noun");
        for (var i = 0; i < checkBox.length; i++) {
            checkBox[i].checked = words.has(checkBox[i].value);
        }
        checkBox = document.getElementsByName("adj");
        for (var i = 0; i < checkBox.length; i++) {
            checkBox[i].checked = words.has(checkBox[i].value);
        }
        checkBox = document.getElementsByName("verb");
        for (var i = 0; i < checkBox.length; i++) {
            checkBox[i].checked = words.has(checkBox[i].value);
        }
    });
});

function wordSelect(word) {
    var words;
    switch (tagID) {
        case "party": words = wordsOfParty; break;
        case "sex": words = wordsOfSex; break;
        case "nationality": words = wordsOfNationality; break;
        case "birthPlace": words = wordsOfBirthPlace; break;
        case "cause": words = wordsOfCause; break;
        case "court": words = wordsOfCourt; break;
    }

    if (word.checked) {
        words.add(word.value);
    } else {
        words.delete(word.value);
    }

    var tag = document.getElementById(tagID);
    var s = "";
    for (var i of words) {
        s += i + ",";
    }
    s = s.substring(0, s.length-1)
    tag.value = s;
}