# coding:utf-8
import eel
import jieba
import jieba.posseg
import jieba.analyse

eel.init('web')


@eel.expose
def create_file(text, name):
    with open("./download/"+name, mode='w', encoding='utf-8') as f:
        f.write(text)


@eel.expose
def jiebafenci(text_sent):
    ans = []
    ans.append([])
    ans.append([])
    ans.append([])
    ans.append([])
    text = text_sent.split('\n')
    text_sent = ""

    for t in range(0, len(text)):
        text_sent += text[t] + '\n'

    jieba.load_userdict("./dict.txt")
    words = list(jieba.posseg.cut(text_sent))
    print(words)
    for i in range(0, len(words)):
        if i >= len(words):
            break
        if words[i].flag[0] == 'n':
            ans[0].append(words[i].word)
        elif words[i].flag[0] == 'a':
            ans[1].append(words[i].word)
        elif words[i].flag[0] == 'v':
            ans[2].append(words[i].word)
        elif '0' <= words[i].word <= '9' or '一' <= words[i].word <= '龥':
            ans[3].append(words[i].word)
    # 返回的是一个四维数组，ans[0]~ans[3]分别是名次，形容词，动词和剩余的不知道什么词
    return ans


@eel.expose
def out(con):
    print(con)


if __name__ == "__main__":
    eel.start('main.html', size=(888, 761))
